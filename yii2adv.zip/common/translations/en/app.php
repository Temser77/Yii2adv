<?php
/**
 * Created by PhpStorm.
 * User: post.user14
 * Date: 06.06.2019
 * Time: 16:26
 */
return [
    'comments_id' => 'ID',
    'comments_description' => 'Comments',
    'comments_task_id' => 'Task ID',
    'comments_creator_id' => 'Creator ID',
    'comments_created' => 'Created',
    'tasks_name' => 'Task',
    'tasks_description' => 'Description',
    'tasks_creator_id' => 'Created by',
    'tasks_responsible_id' => 'Responsible',
    'tasks_deadline' => 'Deadline',
    'tasks_status_id' => 'Status',
    'tasks_created' => 'Created at',
    'tasks_updated' => 'Updated at',
    'users_username' => 'Username',
    'users_password' => 'Password',
    'status' => 'Status',
    'tasks' => 'Tasks',
    'create_task' => 'Create task',
    'search' => 'Search',
    'reset' => 'Reset',
    'save' => 'Save',
    'brandLabel' => "My Task Manager",
    'Home' => 'Home',
    'About' => 'About',
    'Contact' => 'Contact',
    'Login' => 'Login',
    'Logout' => 'Logout',
    'comments' => 'Comments',
    'leave_comment' => 'Leave your comment here',
    'login_or_register' => 'Please login or proceed registration',
    'send' => 'Send',
    'view' => 'View',
    'change' => 'Change',
    'delete' => 'Delete'
];